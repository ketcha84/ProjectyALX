package J51_5;

import J38.CompanyController;

import java.util.Scanner;

public class Run {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Controller controller = new Controller();

        while (true){
            System.out.println("1-dodaj, 2-wyswietl, 3-usun, 4-zmien, 5-koniec");
            String menu = scanner.nextLine();

            if(menu.equals("1")){
                //pytania: imie, nazwisko, telefon, email

            }
            else if(menu.equals("2")){

                //Imię: .... Nazwisko: ..... Telefon: ...... Email: ...
                //Imię: .... Nazwisko: ..... Telefon: ...... Email: ...
                //Imię: .... Nazwisko: ..... Telefon: ...... Email: ...
                //Imię: .... Nazwisko: ..... Telefon: ...... Email: ...
            }
            else if(menu.equals("3")){
                //pytania: nazwisko
            }
            else if(menu.equals("4")){
                //pytania: nazwisko, noweImie, noweNazwisko
            }
            else if(menu.equals("5")){
                break;
            }

        }
    }
}
