package J51_5;

public class Controller {

    public void dodaj(){

    }

    public void pokaz(){

    }

    public void usun(){

    }

    public void zmien(){

    }
}
