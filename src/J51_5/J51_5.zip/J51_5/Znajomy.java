package J51_5;

public class Znajomy {

    public String imie;
    public String nazwisko;
    public String telefon;
    public String email;
}
